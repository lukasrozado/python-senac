class Pessoa{
    constructor(nome, idade, profissao ){
        this.nome = nome
        this.idade = idade
        this.profissao = profissao
}
}

pessoa1 = new Pessoa("Top", "Top", "Dale Dale")

console.log(pessoa1)