class Moto{
    constructor(marca, modelo, ano, ){
        this.marca = marca
        this.modelo = modelo
        this.ano = ano
}
}

moto1 = new Moto("Top", "Top", 2015)

console.log(moto1)